export const server_URL = 'http://localhost:7001';
export const frontEnd_URL = 'http://localhost:8081';