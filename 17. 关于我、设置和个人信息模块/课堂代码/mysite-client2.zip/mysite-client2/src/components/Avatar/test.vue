<template>
  <div>
    <Avatar url="http://mdrs.yuanjin.tech/img/20201031141350.jpg" :size="300" />
  </div>
</template>

<script>
import Avatar from "./";
export default {
  components: {
    Avatar,
  },
};
</script>

<style></style>
