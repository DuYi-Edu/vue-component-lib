<template>
    <div>
        文章类型
    </div>
</template>

<script>
    export default {
        
    }
</script>

<style lang="scss" scoped>

</style>