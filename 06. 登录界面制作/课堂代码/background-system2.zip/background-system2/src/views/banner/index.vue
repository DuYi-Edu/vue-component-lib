<template>
    <div>
        首页标语
    </div>
</template>

<script>
    export default {
        
    }
</script>

<style lang="scss" scoped>

</style>